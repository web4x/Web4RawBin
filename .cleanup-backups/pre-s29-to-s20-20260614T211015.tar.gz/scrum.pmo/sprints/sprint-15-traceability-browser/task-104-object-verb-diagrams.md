<!-- GENERATED FROM SCENARIO UNITS — DO NOT HAND-EDIT -->

[Back to Planning](./planning.md)

# T104: Object.verb Use-Case Diagrams

[task:uuid:104d3e4f-5061-4273-894a-d04040404104]

## Status
- [x] Planned
- [x] In Progress
  - [x] refinement (architect)
  - [ ] creating test cases
  - [x] implementing (architect — diagram authored + rendered)
  - [ ] testing (tester — verify renders + uc:uuid anchors resolve)
- [ ] QA Review
- [ ] Done

## Traceability

- up
  - [requirement:uuid:501c2147-1a7f-4fc6-aafe-5c18f1c67f71](./requirements.md) — R15.3 Object.verb use-case diagrams
  - [Sprint 15 Planning](./planning.md)
  - Tron directive 2026-05-26
- down
  - None (atomic task)
- chain
  - **requirement:** R15.3 in [requirements.md](./requirements.md)
  - **use case:** the diagrams themselves (Object=noun, verb=method) — diagrams/object-verb-usecases.puml
  - **puml:** [diagrams/object-verb-usecases.puml](./diagrams/object-verb-usecases.puml)
  - **class/method:** N/A (authoring artifact — provides uc:uuid anchors for T101-T108)

## Task Description

Author Object.verb-style use-case PUML (Object=noun, verb=method) in
`diagrams/object-verb-usecases.puml` and render the corresponding SVG. Each use case
carries a `uc:uuid` tag so the chain links for T101-T108 resolve to a concrete diagram
element.

## Acceptance Criteria

- [ ] AC1: `diagrams/object-verb-usecases.puml` exists with Object=noun actors and verb=method use cases
- [ ] AC2: Every use case carries a `uc:uuid` tag (v4) referenced by at least one task chain
- [ ] AC3: Use cases cover the object.verb surface needed by T101-T108 (object model, routing, item view, list, detail/overview, browser)
- [ ] AC4: An SVG render of the PUML is produced and checked in alongside the source
- [ ] AC5: PlantUML source renders without syntax errors
- [ ] `npm run build` + version bump

## Dependencies

- **Requires:** T101 (object/verb names)
- **Enables:** chain links for T101-T108

## Definition of Done

- [ ] All AC met; chain links resolve
- [ ] Tests pass, build clean
- [ ] Tron QA approved

## QA Audit & User Feedback

- 2026-05-26: Tron directive (Sprint 15 R1-R4). Quote in requirements.tron-literal.md.

## Subtasks

None (atomic task).

---
*Sprint 15 — Traceability Browser & Object Model*
*Owner: robbin-architect*
*Priority: 2 (diagram authoring)*
