<!-- GENERATED FROM SCENARIO UNITS — DO NOT HAND-EDIT -->

[Back to Planning](./planning.md)

# T121: Data + traceability-chain fix — diagnose what's "very bad", remediate

[task:uuid:a6c66693-4e28-4a2a-be02-0f202084ac95]

## Status
- [ ] Planned
- [ ] In Progress
  - [ ] refinement (architect + req — diagnose phase)
  - [ ] creating test cases
  - [ ] implementing
  - [ ] testing
- [ ] QA Review
- [ ] Done

> QA Review + Done are TRON's gate only — never checked by planner/sync.

## Traceability

`[task:uuid:a6c66693-4e28-4a2a-be02-0f202084ac95]`

- up
  - [Sprint 16 Planning](./planning.md)
  - **requirement:** `[requirement:uuid:e61d14c0-69ce-4e6d-a3f5-9579795188b1]` —
    "The traceability chain data is very bad — diagnose what's wrong and fix it."
    (Tron directive 2026-05-29; req-eng to capture the literal verbatim quote
    in this slot.)
- down
  - None (atomic task — diagnose + fix bundled because the remediation depends on the diagnosis)
- follows
  - [T116: Traceability-chain review](./task-116-chain-review.md) — Pass 5 `[impl:uuid:]` scan + orphan-UC validation
  - [T117: UseCase as class instances in PUML](./task-117-usecase-as-class.md) — Pass 4 PUML UC scan
  - [T119: Test traceability](../sprint-11-traceability/task-119-test-traceability.md) — adds the **test** node to the chain (parallel work; T121 may surface issues T119 also addresses)
- chain (req → usecase → puml → class/method)
  - **requirement:** r121-chain-data-fix (Tron 2026-05-29)
  - **use case:** UC-chainDataDiagnose (new), UC-chainDataRemediate (new); architect adds to S16 PUML
  - **puml:** [diagrams/s16-usecases.puml](./diagrams/s16-usecases.puml) (architect adds the two diagnose/remediate UCs after design)
  - **class/method:** TBD — depends on the diagnosis. Candidates: `src/ts/trace-cli/trace-cli.ts` (parser tightening, orphan reporting), `scrum.pmo/standards/traceability-standard.md` (rule clarification), task files (chain stubs → real ids), PUML files (broken UC ids), `scrum.pmo/traceability-matrix.md` (mis-mappings)

## Task Description

Tron 2026-05-29 (literal quote to be filled in by req-eng):
> "<verbatim Tron quote pending req capture; planner's reading: 'the chain data
> is very bad — fix it'>"

Two-phase task — **bundled** because the remediation cannot start until the
diagnosis is complete.

### Phase 1 — Diagnose (architect + req jointly)

Inventory what's wrong with the current chain data. Walk the chain
`requirement → task → use case → class/method (→ test, post-T119)` against the
graph emitted by trace-cli (Passes 1-5 today; +6 after T119). Catalog every
class of defect. Likely candidates (planner's hypothesis — architect/req
verify and extend):

| Class | Example | Why "bad" |
|-------|---------|-----------|
| C1 — Stub chain | Many older tasks (S1–S10) have `**requirement:** TBD` or no `chain` block | Chain doesn't resolve; T90's audit would fail at scale |
| C2 — Placeholder requirement:uuids | Recent tasks invent ids like `r118-...-d18b-...` that aren't real v4 UUIDs and aren't linked anywhere | Looks traceable, isn't |
| C3 — Orphan UseCases | UCs declared in PUML with no incoming requirement / no outgoing class | T116's existing orphan-UC check flags this; data has many |
| C4 — Broken PUML refs | `puml: diagrams/...` that doesn't exist, or filename mismatch (T117/T113 hit this earlier) | Chain link doesn't resolve in tooling |
| C5 — Method markers absent | Many src/ files lack `[impl:uuid:]` despite T116 Pass 5 expecting them | Test/runtime layers have no upward link |
| C6 — Matrix drift | `scrum.pmo/traceability-matrix.md` rows disagree with the live graph (T102 fix engine should catch — verify) | Single source of truth contested |
| C7 — Duplicate/colliding ids | Two tasks reference the same uuid; or two reqs map to one task without `changes`/`supersedes` annotation | Graph navigation ambiguous |
| C8 — Closed sprints unmigrated | S1-9 still in legacy format (S11 batches T87/T88/T89 are the planned remediation) | Out of scope of T121 to rewrite, but cataloged |

Output: a diagnosis report (markdown table, in this task file under
"Diagnosis (architect + req, <date>)") that lists each defect class, count,
sample affected files/ids, and severity (BLOCKER / HIGH / MEDIUM / LOW for
T119/T90 readiness).

### Phase 2 — Remediate (architect + req lead, expert assists if source change)

Per the diagnosis, design and execute fixes scoped to T121:

- C1 stubs → req-eng fills in real requirement ids on active sprints (S10-S16);
  S1-9 deferred to S11 T87/T88/T89 batches.
- C2 placeholder ids → req-eng formalizes each invented id into a real entry
  in `scrum.pmo/traceability-matrix.md` (or replaces with a proper v4 UUID).
- C3 orphan UCs → architect prunes or links each in `diagrams/*.puml`.
- C4 broken PUML refs → architect fixes filename/path.
- C5 method markers → expert adds `[impl:uuid:]` on the methods covered by
  task scopes (NOT a wholesale src/ sweep — bounded to the methods listed in
  task chain blocks).
- C6 matrix drift → run `npm run trace:check` (T102 engine); architect/req
  reconcile; commit the reconciled matrix.
- C7 duplicate ids → architect flags + req renames; cross-link via
  `changes`/`supersedes` traceability annotation.
- C8 closed sprints — out of scope, hand back to S11 batches (T87-T89). Document the boundary.

Order of operations: C4 + C6 first (cheap to fix, unblock graph parsing); then
C3/C5/C7 (architect-led); then C1/C2 (req-led, sweep across active sprints);
C8 explicitly deferred.

## Acceptance Criteria

- [ ] AC1 — Diagnosis report committed in this task file (Phase 1 output table with classes C1-C8 counts/samples/severity)
- [ ] AC2 — All BLOCKER + HIGH defects from the diagnosis remediated and verified
- [ ] AC3 — `npm run trace:check` (T102 engine) runs clean against the remediated graph, OR documented allowlist with rationale
- [ ] AC4 — `sprint audit` (Web4Articles compliance) passes 0-issue across S10-S16 task files after remediation
- [ ] AC5 — `scrum.pmo/traceability-matrix.md` reconciled with live graph; T102 engine reports consistent
- [ ] AC6 — S1-9 boundary explicitly documented as deferred to S11 T87-T89 (not in T121 scope)
- [ ] AC7 — `npm run build` succeeds; vitest + playwright pass; no regression
- [ ] AC8 — **Version + sw.js bumped IF any client-facing file changed** (per learnings #15); planning/PUML/task-file-only changes likely don't need bump — architect documents the call

## Dependencies

- **Requires:** T116, T117 (trace-cli machinery); T102 (matrix consistency engine)
- **Enables:** T119's test-layer additions land on a clean base; T90 audit gate has a real target; the `/trace` browser shows truthful data
- **Parallel-with:** T119 (test traceability) — coordinate via req; T119 may surface defects T121 also catches

## Definition of Done

- [ ] All AC met; diagnosis report + remediation evidence in this task file
- [ ] `npm run trace:check` clean; sprint audit clean
- [ ] Tests pass, build clean
- [ ] Tron QA approved

## QA Audit & User Feedback

- 2026-05-29: Tron directive — chain data is "very bad", architect + req assigned together to diagnose + fix. Routed via PO. Phase 1 diagnosis COMPLETE (see catalog above). Phase 2 remediation pending PO review of priority order.

## Subtasks

None (atomic — Phase 1 + Phase 2 bundled because remediation depends on diagnosis).
