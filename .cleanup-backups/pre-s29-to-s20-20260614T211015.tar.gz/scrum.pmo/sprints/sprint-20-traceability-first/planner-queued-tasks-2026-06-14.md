# CurrentSprint ADVANCE-ORDER (R20.13 — migrated from queue; planner drives WIP=1 THROUGH the live CurrentSprint instrument)

DRIVING MODEL (dogfood, instrument LIVE): planner.setChain(next narrow chain) → pinCurrent feeds /trace pin-row → driveNext dispatches each role from the OPEN node → det-3x champagne gate → advance() ONLY on genuine-champagne + Tron-QA. Tool: scripts/planner-drive.ts. Skill: scrum.pmo/skills/planner-current-sprint-driving.md.

ADVANCE-ORDER (WIP=1, strict-forward — Tron clears each before next):
  [CURRENT/done] v0.6.24 delivery: R20.13(CurrentSprint LIVE)+R20.11+R20.10+R19.63 champagne (26/209). R20.12 functionalDone.
  [next] QUEUE-1 → QUEUE-2 → QUEUE-3 → QUEUE-4(HIGH regression) → QUEUE-5(R20.9 landscape) — advance() through these as Tron clears.
Inaugural drive PROVEN: setChain(R20.13 chain)→pinCurrent OK, getActiveChain returns 6 ordered hops.

---
# QUEUED tasks (Tron directive: strict-forward uninterrupted; do NOT drive now) — planner 2026-06-14

## QUEUE-1: /trace DETAIL BUG (collection + leaf detail render)
**Owner:** architect (root cause done) → expert fix. **Status:** QUEUED (after strict-forward work).
**Forward-traceable bug→task→fix (req-captured, S20 bugs[], RED tests c8b31e02):**
- BUG8 [12cf7bb5] collection-404 → QUEUE-1 fixes via renderDetailForRef collection-handling.
- BUG9 [1b216edc] leaf-blank → QUEUE-1 fixes via remove 'file' from tagMap.
- When Tron clears queue → expert drives RED→GREEN against these.
**Symptom (Tron):**
- Collection 'Files' node → drawer shows 'Loading / no children' (SHOULD show link.url child).
- Leaf 'link.url' node → EMPTY drawer (SHOULD show file detail).
- Room-level detail WORKS (so the drawer/render path is fine for room type; bug is Files-collection + link.url-leaf specific).
**Root cause + fix-plan (architect-diagnosed 2026-06-14; champagne UNAFFECTED — functional bugs, not chain gaps):**
- BUG1 collection 'Files'→no-children: collection node has a SYNTHETIC uuid (members-/files-<roomUuid>) — NOT a scenario unit → fetchDetailData 404s. FIX (expert): special-case type='collection' in renderDetailForRef — extract parent-room-uuid → fetch /api/trace/children/<roomUuid> → render children as dv-links.
- BUG2 leaf 'link.url'→blank: tagMap file→rb-file-detail is UNREGISTERED/nonexistent → blank. FIX (expert): remove 'file' from tagMap (1-line → falls to working generic rb-detail-view). FOLLOW-UP: build a real rb-file-detail.
**Acceptance:** Files collection shows its link.url children; link.url leaf shows file detail (generic for now); room-level unchanged.

## QUEUE-2: 2-orphan-prune cleanup (aggregate hygiene)
**Owner:** expert. **Status:** QUEUED. **NOT data-loss — DATA-SAFE already sealed (all 11 reals present, 0 lost).**
**What:** data/profiles.json has 2 STALE TEST orphan entries (no dir): E2E-webkit (4e5655bf) + test-merge (ae9a8a5e). Earlier '24/0' was transient/uncommitted; fresh read of data/profiles.json = 26 with the 2 orphans still present.
**Fix:** prune the 2 stale entries from data/profiles.json (written+saved to file) → aggregate==profiled-dirs(23), orphans=0. Then planner re-confirms clean-seal.
**Also (separate, later):** SystemTester x8 → consolidate to canonical ce981242 (conservative-keep now).

## QUEUE-3: BUG10 [da4a27bc] — collection blank in ROOM surface (BUG8 family)
**Owner:** expert. **Status:** QUEUED. Same root cause class as BUG8 (collection synthetic-uuid 404), second surface (in-room). intendedChain + RED captured by req. Fix likely shares BUG8's renderDetailForRef collection-handling.

## QUEUE-4: BUG11 [871c5cf9] — ⚠ HIGH PRIORITY REGRESSION: URL buttons do nothing
**Owner:** expert. **Status:** QUEUED (HIGH — regression from v0.6.10 drawer consolidation). intendedChain + RED captured by req. PRIORITIZE when Tron clears the queue.
**Root cause (architect-diagnosed):** MODE CONFLICT — openFilePreview (OLD path) sets the preview panel AND setAttribute('ref') → that triggers renderDetailForRef (NEW path) → switches to the detail panel → preview hidden (URL action appears dead).
**Fix (architect-recommend b, expert):** REMOVE the OLD openFilePreview path + file-tree click handler (lines ~198-207 / 235-251); route file clicks via handleTapSelect → selectionModel → renderDetailForRef → rb-detail-view (already has createFilePreviewButton + wireUrlActions @:140) = SINGLE-PATH, no mode conflict.
**Note:** BUG10 (da4a27bc) shares BUG8's synthetic-UUID collection root, affecting BOTH /trace + room surfaces — same collection-detail-handler fix.

## FIX FAMILIES (queue consolidation)
- **Collection-fix** = BUG8 (/trace) + BUG10 (room) → renderDetailForRef handle type='collection' (extract parent-room-uuid → /api/trace/children → dv-links), BOTH surfaces.
- **Leaf/file-fix** = BUG9 (remove 'file' from tagMap) + BUG11 (remove OLD dual-path → single selection→renderDetailForRef).
All 4 diagnosed, RED-tested, forward-traceable, QUEUED for Tron's clear. BUG11 = PRIORITY (regression).

## QUEUE-5: Landscape-responsive design — REQ R20.9 [678ed4f1]
**Owner:** req R20.9 678ed4f1 (intendedChain defined) → architect design (done) → expert. **Status:** QUEUED (when Tron prioritizes).
**Design (architect, PO-detailed):** CSS-only — @media (orientation:landscape) and (max-width:1024px) → .trace-page/.room-view flex-direction:row (side-by-side):
- tree LEFT (flex:1, scroll, border-right)
- drawer RIGHT (position:static, flex:1, max-width:50vw, FULL-height — not the 40vh-cap; grab-bar hides, as it already does at ≥1025)
- orientation+max-width:1024 limits to NARROW landscape; desktop ≥1025 already side-by-side (unchanged); portrait UNCHANGED.
**Interactions (all compatible):** BUG5 zero-overlap (side-by-side), BUG8-11 renderDetailForRef layout-independent, ChatPanel layout-independent.
**Acceptance:** narrow landscape (≤1024px) shows tree-left/drawer-right side-by-side, zero overlap, drawer full-height; portrait + desktop ≥1025 unchanged.
