<!-- GENERATED FROM SCENARIO UNITS — DO NOT HAND-EDIT -->

[Back to Sprints](../sprints.overview.md)

# Sprint 17 Planning — Sprint 17 — Scenario Units

## Sprint Goal



**Status:** In Progress

## Tasks

- [ ] [T124: Scenario-unit + IOR + class-based view architecture](./task-124-architecture.md)
  - [ ] [T124.1: Architect — Scenario-Unit + IOR Data Model](./task-124.1-architect-data-model.md)
  - [ ] [T124.2: Architect — View Template Architecture](./task-124.2-architect-view-templates.md)
  - [ ] [T124.3: Architect — Storage Layout (Index + Speaking-Name Trees)](./task-124.3-architect-storage-layout.md)
- [ ] [T125: Scenario-unit primitives + class system + storage](./task-125-foundation.md)
- [ ] [T126: Generated views — planning.md, sprints.md, per-instance .md/.html](./task-126-views.md)
- [ ] [T127: File-browser ↔ traceability-browser navigation + IOR universal handler](./task-127-navigation.md)
- [ ] [T128: Migrate all existing sprints/tasks/requirements to scenario-unit model](./task-128-migration.md)
- [ ] [T129: Traceability gate — every method traces to a task AND a requirement](./task-129-verification.md)
- [ ] [T131: File-browser symlink support (FileApi + rb-file-tree)](./task-131-file-browser-symlinks.md)
- [ ] [T132: HTML status template fix](./task-132-html-status-template-fix.md)
- [ ] [T133: Task state-machine + status methods](./task-133-task-state-machine.md)
- [ ] [T134: Traceability-as-units (links as scenario.json with ln in referenced instances + MD/HTML views)](./task-134-traceability-as-units.md)
- [ ] [T135: req-audit — formalize backlog Tron quotes req missed](./task-135-req-audit.md)
- [ ] [T136: Migration extension for Requirement + UseCase units (T128 extension)](./task-136-migration-extension-req-uc.md)
- [ ] [T137: req + planner LEARN scenarios for planning + update SKILL.md](./task-137-req-planner-learn-scenarios.md)
- [ ] [T138: skill set on scenarios (capture-quote, propose-task, walk-chain)](./task-138-skill-set-scenarios.md)
- [ ] [T139: fork skill-expert from expert (PO decision; agent-trainer executes)](./task-139-fork-skill-expert.md)
- [ ] [T140: Source-Location IOR for UC/Class/Method Scenario Units](./task-140-source-location-ior.md)
- [ ] [T141: Chain-link icon → sprints.json symlink in generated MD views](./task-141-chain-link-icon-symlinks.md)
- [ ] [T143: Traceability chain → TREE rework (R17.26–R17.29)](./task-143-traceability-tree-rework.md)
- [ ] [T144: File-browser display fixes — icon order + link targets (B5, 3 fixes)](./task-144-file-browser-display-fixes.md)
- [ ] [T145: User class as scenario-unit + ViewBus-driven view updates (fixes lobby/room name stale)](./task-145-user-scenario-viewbus.md)
- [ ] [T146: Requirement-entry format reform — 3–5 word NAME first line + speaky-NAME on 🔗](./task-146-requirement-name-first-format.md)
- [ ] [T147: Chain-link icon in `/md/` directory listing for `scenarios/sprints.md/` subtrees (symmetric UX with `.json` side)](./task-147-md-listing-chain-link-icon.md)
- [ ] [T148: File-browser path-header clickable → parent dir navigation](./task-148-file-browser-path-header-clickable.md)
- [ ] [T149: Extend symlink tree to all 9 scenario classes — universal 🔗 resolution](./task-149-symlink-tree-all-9-classes.md)
- [ ] [T150: File-browser breadcrumb link color contrast fix (CSS)](./task-150-breadcrumb-link-contrast.md)
- [ ] [T151: Migrate MD traceability bullets → JSON model arrays (no info loss)](./task-151-md-traceability-to-json-arrays-migration.md)
- [ ] [T152: UseCase data quality — derive object/verb from name + populate tasks/classes/requirement links from PUML](./task-152-usecase-data-quality-object-verb-from-name-puml-links.md)
- [ ] [T153: T152 follow-up — populate `model.classes` + `model.requirement` on UseCases](./task-153-populate-classes-requirement-on-ucs.md)
- [ ] [T154: Requirement data quality — name vs description split + `tasks[]` populated](./task-154-requirement-data-quality-name-description-tasks.md)
- [ ] [T155: Requirement `tasks[]` + `tests[]` bidirectional closure](./task-155-requirement-tasks-tests-bidirectional-closure.md)
- [ ] [T156: Reload button on Connection-Failed + Offline pages](./task-156-reload-button-connection-failed-offline.md)
- [ ] [T157: Profile gate — Upload vCard for fast onboarding (button + native drag-and-drop)](./task-157-profile-gate-vcard-onboarding.md)
- [ ] [T158: Traceability browser — surface the FULL chain data (Req → Task → UC → Class → Method → Impl → Test)](./task-158-traceability-browser-full-chain-data.md)
- [ ] [T159: Forward-only traceability chain — refactor (remove back-refs)](./task-159-forward-only-traceability-chain-refactor.md)
- [ ] [T160: Forward-ref REPOPULATION + browser data-freshness (T159 over-strip root cause)](./task-160-trace-browser-stale-requirement-items.md)
- [ ] [T161: Requirement items render Tron-quote as NAME instead of speaky `model.name` (bug)](./task-161-requirement-name-renders-tron-quote-not-speaky.md)
- [ ] [T162: MD artifacts (`##` headings) leak into requirement titles](./task-162-md-headings-leak-into-requirement-titles.md)
- [ ] [T163: /api/trace requirement title source — switch from scanRepo firstLine() to scenario index `model.name`](./task-163-api-trace-title-source-switch.md)
- [ ] [T164: Re-migrate dirty model.name + firstLine() fallback hardening](./task-164-dirty-model-name-remigration.md)
- [ ] [T165: Traceability tree renders ALL 7 typed classes (not only Requirements)](./task-165-tree-renders-all-7-typed-classes.md)
- [ ] [T166: /api/trace populate Class + Method types from scenario index](./task-166-api-trace-populate-class-method-from-scenario-index.md)
- [ ] [T167: /trace mobile-first layout + hard width-cap on right (detail) pane](./task-167-trace-mobile-first-layout-width-cap.md)
- [ ] [T168: Chain order 7-step + atomic requirements as tree ROOTS](./task-168-chain-order-7-step-requirements-as-roots.md)
- [ ] [T169: Data-quality audit + remigrate — complete tree, NO back-chaos, NO untraced scenarios (KEYSTONE)](./task-169-data-quality-audit-remigrate-complete-tree.md)
- [ ] [T170: Diligent plan + no-stop sustain (cadence + quality gates)](./task-170-diligent-plan-no-stop-sustain.md)
- [ ] [T171: Untraced-closure — link 50 untraced + R17.26 link-back to T165/T166 + traceability-matrix refresh (T143-T171)](./task-171-untraced-closure-r17-26-linkback.md)
- [ ] [T173: .scenario.json click → /trace tree + lazy-load (consolidates R-K1 + R-L; covers R-K2 + R-K3)](./task-173-file-browser-scenario-click-to-trace.md)
