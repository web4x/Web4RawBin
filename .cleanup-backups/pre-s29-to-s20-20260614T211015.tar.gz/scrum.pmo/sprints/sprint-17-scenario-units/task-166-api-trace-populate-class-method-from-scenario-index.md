<!-- GENERATED FROM SCENARIO UNITS — DO NOT HAND-EDIT -->

[Back to Planning](./planning.md)

# T166: /api/trace populate Class + Method types from scenario index

[task:uuid:086a35db-0de3-49f3-971a-c6be1863100e]

## Status
- [ ] Planned
- [ ] In Progress
- [ ] QA Review
- [ ] Done

## Traceability

`[task:uuid:086a35db-0de3-49f3-971a-c6be1863100e]`

- up
  - [Sprint 17 Planning](./planning.md)
  - **Tester finding on T165 verification (planner-anchored, req-eng to formalize verbatim):**
    `[requirement:uuid:92c25e03-0b67-4a2e-bf12-dda2df412c4a]`
    Tester (2026-06-02 via PO): T165 PARTIAL — 5/7 classes render in `/trace` graph (requirement, task, useCase, test, implementation). **Class and Method = 0 nodes** because `scanRepo` (the current `/api/trace` data source for non-Requirement types) does not produce them. The data exists: T128.1 migrated Sprint 1 class/method units to the scenario index. Fix: populate Class + Method types in `/api/trace` from the scenario index — same sister-pattern as T163 (data-source switch to scenario index).
- down
  - None (atomic; single-endpoint overlay/walk change)
- follows
  - [T165: tree renders ALL 7 typed classes](./task-165-tree-renders-all-7-typed-classes.md) — `60a97a7` architect design; T165 closes 5/7 but Class+Method blocked by missing source data; T166 unblocks
  - [T163: /api/trace title source switch](./task-163-api-trace-title-source-switch.md) — sister pattern (data-source switch to scenario index)
  - [T160: forward-ref REPOPULATION](./task-160-trace-browser-stale-requirement-items.md) — sister pattern (forward-refs from scenario index)
  - [T128.1: Sprint 1 exemplar migration](./task-128-migration.md) — supplies the migrated Class + Method scenario-index units T166 surfaces
  - [T158: 4 typed DetailViews](./task-158-traceability-browser-full-chain-data.md) — destination DetailViews for Class + Method tree-items
- chain (req → usecase → puml → class/method) — architect fills on refinement
  - **requirement:** Class + Method in /api/trace (anchored above)
  - **use case:** UC-TBD (architect — likely `api.trace.overlayClassMethod` or `traceEndpoint.surfaceFromIndex`)
  - **puml:** [diagrams/s17-usecases.puml](./diagrams/s17-usecases.puml) (architect adds UC if introduced)
  - **class/method:** `src/ts/server/` `/api/trace` route handler — overlay/walk pulling Class + Method from scenario index (TBD by architect)

## Context

T165 (`60a97a7` architect design committed) targets full 7-class tree
rendering in `/trace`. Tester verification: **5/7 work** (Requirement, Task,
UseCase, Test, Implementation render correctly). **Class + Method = 0
nodes** in the graph because `/api/trace`'s current source (`scanRepo`) doesn't
produce them.

The data is NOT missing — T128.1 migrated Sprint 1's class/method units to the
scenario index. The graph just doesn't read from there for these types.

**Sister pattern to T163.** T163 switched `/api/trace` requirement-title source
from a derived path → scenario-index `model.name`. T166 does the same kind of
move for Class + Method: surface them in the `/api/trace` graph by walking /
overlaying the scenario index, instead of relying on scanRepo's incomplete
output.

Architect decides: full data-source switch (scenario-index only for Class +
Method) vs overlay (merge scanRepo + scenario-index). Overlay is safer if
scanRepo carries any data scenario-index lacks; full switch is cleaner if
scenario-index is authoritative post-T128.1.

## Intention

### Why this task exists
T165 cannot reach 7/7 without Class + Method appearing in `/api/trace`'s
output. The fix is upstream of the tree builder — at the data-source layer.

### Problems this task solves
- `/api/trace` returns 0 Class + Method nodes despite migrated data existing
- T165 visually blocked at 5/7 classes for tree-coverage AC
- Click-through into T158's Class / Method DetailViews unreachable from the tree

### How it solves them
- Architect designs the overlay/walk: scenario-index supplies Class + Method
  graph nodes (with their forward refs); `/api/trace` merges into its response
- Expert implements as a single endpoint change in one commit-set
- Tree builder (T165) now has 7/7 typed objects to render

## Acceptance Criteria

- [ ] AC1 — `GET /api/trace` returns Class nodes populated from the scenario index (count > 0; verify against T128.1's migrated S1 class units)
- [ ] AC2 — `GET /api/trace` returns Method nodes populated from the scenario index (count > 0)
- [ ] AC3 — Class + Method nodes carry their forward refs (per T160 forward-only rule) — no back-refs reintroduced
- [ ] AC4 — Class + Method titles use scenario-index `model.name` (T161/T163 clean) — no MD prefix leak
- [ ] AC5 — Click-through from `/trace` Class / Method tree-items opens T158's DetailViews correctly
- [ ] AC6 — T165 verify target met: **7/7 classes** render in the `/trace` graph
- [ ] AC7 — No regression on T158 / T160 / T161 / T163 / T165 (existing 5 classes unchanged)
- [ ] AC8 — `npm run build` succeeds; all existing tests pass
- [ ] AC9 — **Rule-pair (a)+(b) [learnings #15+#16]:** `package.json` "version" bumped AND `src/public/sw.js` CACHE_NAME bumped in the SAME commit-set; (c) STATIC_SHELL exempt (no new route, architect to confirm)

## Dependencies

- **Requires:** T165 (`60a97a7` architect design — tree builder ready to consume the 7/7), T128.1 (shipped — class/method scenario-index units exist), T158 (shipped — destination DetailViews), T160 + T163 (sister-pattern data-source switches)
- **Coordinate-with:** T128.2 (S10-S16 migration in flight — once landed, more Class + Method units available to surface; T166's overlay/walk should cover them automatically)
- **Enables:** T165 reaches 7/7; complete tree-shaped traceability across all typed scenarios

## Definition of Done

- [ ] All AC met
- [ ] Rule-pair (a)+(b) ✓
- [ ] No regression on T158 / T160 / T161 / T163 / T165
- [ ] All 4 roles committed work
- [ ] Tron QA approved
- [ ] T165 status updates to ✅-ready once T166 lands (T165's 7/7 AC depends on T166)

## QA Audit & User Feedback

- 2026-06-02: PO directed planner-first stand-up of T166 — tester T165 partial finding (5/7 classes; Class + Method = 0 because scanRepo doesn't produce them). Sister to T163 overlay/data-source-switch pattern. CMM4 4-role (learnings #18); real v4 uuids (learning #17); rule-pair (a)+(b) baked into AC9 + DoD (learnings #15+#16). Awaiting req-eng anchor → architect design → expert impl → tester verify → Tron QA.

## Subtasks

None (atomic task; single-endpoint overlay/walk change).

---

*Sprint 17 — Scenario Units / IOR Data Model & Class Views · Phase 27 follow-on (T165 unblocker)*
*Owners (CMM4): robbin-req → robbin-architect → robbin-expert → robbin-tester*
*Priority: 2 (unblocks T165's 7/7 target; closes the Class+Method data-source gap at /api/trace)*
