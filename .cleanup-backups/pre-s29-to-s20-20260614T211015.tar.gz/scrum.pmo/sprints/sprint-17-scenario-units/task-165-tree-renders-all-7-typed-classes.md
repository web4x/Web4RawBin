<!-- GENERATED FROM SCENARIO UNITS — DO NOT HAND-EDIT -->

[Back to Planning](./planning.md)

# T165: Traceability tree renders ALL 7 typed classes (not only Requirements)

[task:uuid:35ed4168-f575-4df4-9a87-43f5ca4912ab]

## Status
- [ ] Planned
- [ ] In Progress
- [ ] QA Review
- [ ] Done

## Traceability

`[task:uuid:35ed4168-f575-4df4-9a87-43f5ca4912ab]`

- up
  - [Sprint 17 Planning](./planning.md)
  - **Tester finding on T158 verification (planner-anchored, req-eng to formalize verbatim):**
    `[requirement:uuid:f6f5b204-0595-4910-998f-5089025ec494]`
    Tester (2026-06-02, via PO): the graph tree on `/trace` shows ONLY Requirements as tree-items. The four typed DetailViews shipped in T158 (Class / Method / Test / Implementation) exist and render correctly when reached, but their objects do not appear as tree-items in the tree itself. Tron requests full **7-class tree rendering** (architect to enumerate the 7 — likely Requirement, UseCase, Task, Class, Method, Test, Implementation/TraceLink — with architect confirming).
  - **Aligns with [R17.26-R17.29](./requirements.md) (T143 traceability-as-tree rework):**
    - R17.26 (tree, not chain): the tree must include all typed scenarios
    - R17.27 (every element a link): each tree-item navigates to its DetailView (T158 provides 4 of the 7)
    - R17.28 (all typed scenarios): coverage of all class types in the tree
    - This task is one of the R17.29 "rework refined task files" workstream deliverables for the browser surface
- down
  - None at the parent level (architect may split T164.x sub-tasks if scope warrants — coordinate with planner first)
- follows
  - [T158: 4 typed DetailViews — Class/Method/Test/Implementation](./task-158-traceability-browser-full-chain-data.md) (shipped `a41d16a` v0.5.59) — provides the destination DetailViews this task's tree-items link to
  - [T143: Traceability chain → TREE rework (R17.26-R17.29)](./task-143-traceability-tree-rework.md) — parent direction; T164 is one concrete consumer of T143's tree model on the `/trace` browser
  - [T160: Forward-ref REPOPULATION + browser data-freshness](./task-160-trace-browser-stale-requirement-items.md) (shipped, AC3 verified) — supplies the forward-ref tree edges (Req→Task / Task→UC) the tree builder walks
  - [T161: Requirement name rendering — speaky model.name](./task-161-requirement-name-renders-tron-quote-not-speaky.md) (shipped) — T164 reuses speaky-name rendering across all 7 classes
  - [T163: /api/trace title source switch](./task-163-api-trace-title-source-switch.md) (shipped) — T164 inherits the clean title pipeline
- chain (req → usecase → puml → class/method) — architect fills on refinement
  - **requirement:** all-7-class tree rendering (anchored above)
  - **use case:** UC-TBD (architect — likely `tree.buildAll7Classes` or `traceTree.renderTypedItem`)
  - **puml:** [diagrams/s17-usecases.puml](./diagrams/s17-usecases.puml) (architect adds UC if introduced; first-class UseCase instances per R17.10 / T117 pattern)
  - **class/method:** `src/public/ts/trace/` — `rb-tree-item` (generalize per type), tree builder (root-set + child-edge derivation), per-class registration; TBD by architect

## Context

T158 (shipped `a41d16a` v0.5.59) delivered 4 typed DetailViews (Class / Method /
Test / Implementation) alongside the previously-existing Requirement DetailView.
Tester verification on T158 found a coverage gap: the **tree itself** in
`/trace` still only renders Requirement items as tree-nodes. The Class /
Method / Test / Implementation DetailViews exist and work when navigated to
(e.g. via chain-link anchors or direct URL), but their objects are not
visible as tree-items in the tree's structure.

Tron (via PO 2026-06-02) directs that ALL 7 typed scenario classes appear as
tree-items, per the R17.26-R17.28 tree-coverage requirements that T143 sets
as the architectural direction. Architect leads the design (PO assignment).

The "7 classes" enumeration is architect-confirmable but most likely:
**Requirement, UseCase, Task, Class, Method, Test, Implementation** (= TraceLink
class per S17 model). Confirm against the scenario-class registry shipped in
T125 (Unit + ClassRegistry + ScenarioIndex) and the templates in T126.

## Intention

### Why this task exists
T158 closed the DetailView gap (4 typed views) but not the tree-item-coverage
gap. Without T164, users can't navigate to typed objects from the tree itself —
they have to follow chain-links or know URLs. Breaks the discoverability of
the tree-shaped traceability per R17.26.

### Problems this task solves
- Tree on `/trace` shows only Requirements as nodes
- Class / Method / Test / Implementation objects are invisible at the tree level
- UseCase / Task tree-item coverage status: architect to confirm (likely partial)

### How it solves them
- Generalize `rb-tree-item` per type (or one component with per-type render)
- Tree builder walks the forward-ref graph (T160 forward arrays) AND the typed
  registries to surface every scenario object as a tree-item under appropriate
  parents
- Each tree-item navigates to its T158 DetailView (existing) on click

## Acceptance Criteria

- [ ] AC1 — All 7 typed scenario classes (architect to enumerate + confirm) appear as tree-items in `/trace`
- [ ] AC2 — Clicking any tree-item opens its corresponding T158 DetailView (Class/Method/Test/Impl) or existing Requirement/UseCase/Task DetailView
- [ ] AC3 — Tree-item rendering is consistent with T143 (speaky name + word-wrap description + square SVG icon when T113 lands; for now, per-type icon convention defined by architect)
- [ ] AC4 — Tree-item parent/child edges follow the forward-ref graph (T160's repopulated arrays) — no back-refs introduced (R17 forward-only rule)
- [ ] AC5 — Chain audit on `/trace` shows zero orphan typed objects (every typed scenario appears in the tree at least once)
- [ ] AC6 — No regression on T158 / T160 / T161 / T163; existing Requirement tree-items render unchanged
- [ ] AC7 — `npm run build` succeeds; all existing tests pass
- [ ] AC8 — **Rule-pair (a)+(b) [learnings #15+#16]:** `package.json` "version" bumped AND `src/public/sw.js` CACHE_NAME bumped in the SAME commit-set; (c) STATIC_SHELL exempt (no new route, architect to confirm)

## Dependencies

- **Requires:** T158 (shipped — destination DetailViews), T160 (shipped — forward-ref edges), T161 (shipped — speaky names), T163 (shipped — clean /api/trace titles), T143 (parent direction — tree model design)
- **Coordinate-with:** T141 (chain-link icon), T126 (per-class templates), T125 (ClassRegistry + ScenarioIndex — the 7-class enumeration source)
- **Enables:** complete tree-shaped traceability navigation per R17.26-R17.28

## Definition of Done

- [ ] All AC met
- [ ] Rule-pair (a)+(b) ✓
- [ ] No regression on T158 / T160 / T161 / T163
- [ ] All 4 roles committed work
- [ ] Tron QA approved

## QA Audit & User Feedback

- 2026-06-02: PO directed planner to stand up T164 — tester finding during T158 verification: graph tree shows only Requirements; class/method/test/impl have DetailViews but no tree-items yet. Architect-LED design (PO assignment). CMM4 4-role engagement enforced (learnings #18); real v4 uuids (learning #17); rule-pair (a)+(b) baked into AC8 + DoD (learnings #15+#16). Awaiting req-eng anchor → architect design → expert impl → tester verify → Tron QA.

## Subtasks

None at parent level (architect may split T165.x if scope warrants — coordinate with planner first).

---

*Sprint 17 — Scenario Units / IOR Data Model & Class Views · Phase 27 (tree-coverage enrichment)*
*Owners (CMM4): robbin-req → robbin-architect (LEAD) → robbin-expert → robbin-tester*
*Priority: 2 (closes the discoverability gap left by T158; aligns `/trace` tree with R17.26-R17.28)*
